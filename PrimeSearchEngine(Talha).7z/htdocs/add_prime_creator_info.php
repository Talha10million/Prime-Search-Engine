<?php
// add_prime_creator_info.php - Add Muhammad Talha's information to the database

require_once 'db_connect.php';

// Detailed creator information entries
$creatorEntries = [
    [
        'url' => 'https://github.com/Talha10million',
        'title' => 'Prime Search Engine Creator - Muhammad Talha (Shadow Emperor)',
        'description' => 'Meet Muhammad Talha (Shadow Emperor), the developer behind Prime Search Engine - a futuristic search platform with advanced visual effects.',
        'content' => 'Prime Search Engine was created by Muhammad Talha, also known as Shadow Emperor. He is a passionate computer science student and cybersecurity enthusiast who developed Prime as an innovative search platform. The engine features holographic cursors, parallax backgrounds, dynamic search results, keyboard navigation, dark/light mode, and many other advanced features.'
    ],
    [
        'url' => 'https://linkedin.com/in/muhammad-talha',
        'title' => 'About Prime Search Engine - A Project by Muhammad Talha',
        'description' => 'Prime is not just another search engine — it\'s designed with simplicity, performance, and innovation in mind by Muhammad Talha (Shadow Emperor).',
        'content' => 'Prime Search Engine is a cutting-edge search platform designed for modern web browsing. Created by Muhammad Talha (Shadow Emperor), it features holographic cursor effects, parallax backgrounds, keyboard navigation, dark/light mode, search result animations, and more. Prime aims to grow into a multi-functional platform, connecting users with information in smarter ways.'
    ],
    [
        'url' => 'https://instagram.com/talha10million',
        'title' => 'Muhammad Talha (Shadow Emperor) - Developer Portfolio',
        'description' => 'Cybersecurity enthusiast and developer behind Prime Search Engine. Specializing in PHP, C++, cybersecurity, and AI projects.',
        'content' => 'Muhammad Talha (Shadow Emperor) is a computer science student and cybersecurity enthusiast passionate about building futuristic technology projects. Currently interning at Skeler Security, he specializes in PHP/MySQL, C++ programming, and AI-driven projects. His portfolio includes Prime Search Engine, a Hybrid Quantum-Driven Interstellar Management System, and various custom management systems.'
    ],
    [
        'url' => 'https://github.com/Talha10million?tab=projects',
        'title' => 'Prime Creator Projects - Muhammad Talha',
        'description' => 'Explore projects by Muhammad Talha (Shadow Emperor) including Prime Search Engine and other innovative systems.',
        'content' => 'Projects by Muhammad Talha (Shadow Emperor) include Prime Search Engine - a futuristic search platform with holographic effects, a Hybrid Quantum-Driven Interstellar Management System exploring quantum-inspired system design, various custom-built management systems, and C++ learning projects. He also explores AI-driven projects and search systems.'
    ],
    [
        'url' => 'https://discord.com/users/talha10millionx',
        'title' => 'Connect with Prime Creator - Muhammad Talha (Shadow Emperor)',
        'description' => 'Connect with Muhammad Talha (Shadow Emperor), the creator of Prime Search Engine, via GitHub, LinkedIn, Instagram, or Discord.',
        'content' => 'Connect with Muhammad Talha (Shadow Emperor), the creator of Prime Search Engine: GitHub: github.com/Talha10million, LinkedIn: Muhammad Talha, Instagram: @talha10million, Discord: talha10millionx. Email: talhaxworks@gmail.com. He is a cybersecurity enthusiast and developer passionate about building futuristic technology projects.'
    ]
];

$addedCount = 0;
$skippedCount = 0;

foreach ($creatorEntries as $entry) {
    // Check if similar entry already exists based on title
    $checkSql = "SELECT id FROM websites WHERE title = :title";
    $checkStmt = $pdo->prepare($checkSql);
    $checkStmt->bindValue(':title', $entry['title']);
    $checkStmt->execute();
    
    if ($checkStmt->rowCount() == 0) {
        // Insert new entry
        $insertSql = "INSERT INTO websites (url, title, description, content) VALUES (:url, :title, :description, :content)";
        $insertStmt = $pdo->prepare($insertSql);
        
        $insertStmt->bindValue(':url', $entry['url']);
        $insertStmt->bindValue(':title', $entry['title']);
        $insertStmt->bindValue(':description', $entry['description']);
        $insertStmt->bindValue(':content', substr($entry['content'], 0, 5000));
        
        if ($insertStmt->execute()) {
            $addedCount++;
            echo "<p style='color: green;'>✓ Added: " . htmlspecialchars($entry['title']) . "</p>";
        } else {
            echo "<p style='color: red;'>✗ Failed to add: " . htmlspecialchars($entry['title']) . "</p>";
        }
    } else {
        $skippedCount++;
        echo "<p style='color: orange;'>→ Skipped (exists): " . htmlspecialchars($entry['title']) . "</p>";
    }
}

echo "<h2>Creator Information Update Complete</h2>";
echo "<p>Added <strong>$addedCount</strong> new entries about Muhammad Talha (Shadow Emperor).</p>";
echo "<p>Skipped <strong>$skippedCount</strong> entries that already existed.</p>";
echo "<p><br>Now you can search for terms like:</p>";
echo "<ul>";
echo "<li><strong>Muhammad Talha</strong></li>";
echo "<li><strong>Shadow Emperor</strong></li>";
echo "<li><strong>Prime creator</strong></li>";
echo "<li><strong>About Prime</strong></li>";
echo "<li><strong>Prime developer</strong></li>";
echo "<li><strong>Muhammad Talha projects</strong></li>";
echo "<li><strong>Who made Prime</strong></li>";
echo "</ul>";
echo "<p>And see your information appear in the search results!</p>";
?>