<?php
// populate_db.php - Script to populate the database with programming resources

require_once 'db_connect.php';

// Array of programming language resources to add
$resources = [
    // Python resources
    ['https://www.python.org/', 'Python', 'The official home of the Python Programming Language'],
    ['https://docs.python.org/', 'Python Documentation', 'Python Documentation'],
    ['https://pypi.org/', 'Python Package Index', 'The Python Package Index (PyPI)'],
    
    // JavaScript resources
    ['https://developer.mozilla.org/en-US/docs/Web/JavaScript', 'JavaScript Docs', 'JavaScript documentation on MDN'],
    ['https://nodejs.org/', 'Node.js', 'Node.js JavaScript runtime'],
    ['https://www.w3schools.com/js/', 'JavaScript Tutorial', 'JavaScript tutorial on W3Schools'],
    
    // Java resources
    ['https://www.java.com/', 'Java', 'Get started with Java today'],
    ['https://docs.oracle.com/javase/', 'Java Documentation', 'Java Platform SE Documentation'],
    ['https://openjdk.org/', 'OpenJDK', 'Open-source implementation of Java Platform'],
    
    // C/C++ resources
    ['https://docs.microsoft.com/en-us/cpp/', 'C++ Documentation', 'Microsoft C++ documentation'],
    ['https://gcc.gnu.org/', 'GCC', 'GNU Compiler Collection'],
    ['https://isocpp.org/', 'C++ Official', 'C++ Official site'],
    
    // C# resources
    ['https://dotnet.microsoft.com/languages/csharp', 'C# Language', 'C# Programming Language'],
    ['https://docs.microsoft.com/en-us/dotnet/csharp/', 'C# Documentation', 'C# Documentation'],
    
    // PHP resources
    ['https://www.php.net/', 'PHP', 'PHP: Hypertext Preprocessor'],
    ['https://www.php.net/manual/en/', 'PHP Manual', 'PHP Manual'],
    
    // Ruby resources
    ['https://www.ruby-lang.org/', 'Ruby', 'The Ruby Programming Language'],
    ['https://docs.ruby-lang.org/', 'Ruby Documentation', 'Ruby Documentation'],
    
    // Go resources
    ['https://go.dev/', 'Go', 'The Go Programming Language'],
    ['https://pkg.go.dev/', 'Go Packages', 'Go Packages documentation'],
    
    // Rust resources
    ['https://www.rust-lang.org/', 'Rust', 'A language empowering everyone'],
    ['https://doc.rust-lang.org/', 'Rust Documentation', 'Rust Documentation'],
    
    // Swift resources
    ['https://swift.org/', 'Swift', 'Swift Programming Language'],
    
    // Kotlin resources
    ['https://kotlinlang.org/', 'Kotlin', 'Kotlin Programming Language'],
    
    // TypeScript resources
    ['https://www.typescriptlang.org/', 'TypeScript', 'TypeScript is JavaScript with syntax'],
    
    // Web development
    ['https://developer.mozilla.org/en-US/', 'MDN Web Docs', 'Resources for developers'],
    ['https://www.w3schools.com/', 'W3Schools', 'Online Web Tutorials'],
    ['https://css-tricks.com/', 'CSS-Tricks', 'CSS-Tricks'],
    
    // Popular learning platforms
    ['https://www.freecodecamp.org/', 'freeCodeCamp', 'Learn to code for free'],
    ['https://www.codecademy.com/', 'Codecademy', 'Learn to code'],
    ['https://www.udemy.com/', 'Udemy', 'Online Courses'],
    ['https://www.coursera.org/', 'Coursera', 'Online Courses'],
    
    // Documentation sites
    ['https://devdocs.io/', 'DevDocs', 'API Documentation'],
    
    // Community resources
    ['https://stackoverflow.com/', 'Stack Overflow', 'Stack Overflow'],
    ['https://github.com/', 'GitHub', 'GitHub'],
    
    // Git
    ['https://git-scm.com/', 'Git', 'Git Version Control'],
    ['https://docs.github.com/', 'GitHub Docs', 'GitHub Documentation'],
    
    // React
    ['https://reactjs.org/', 'React', 'A JavaScript library for building user interfaces'],
    
    // Angular
    ['https://angular.io/', 'Angular', 'Platform for building mobile and desktop web applications'],
    
    // Vue.js
    ['https://vuejs.org/', 'Vue.js', 'The Progressive JavaScript Framework'],
    
    // Data science
    ['https://pandas.pydata.org/', 'Pandas', 'Python Data Analysis Library'],
    ['https://numpy.org/', 'NumPy', 'NumPy is the fundamental package for scientific computing'],
    ['https://scikit-learn.org/', 'Scikit-learn', 'Machine Learning in Python'],
    
    // DevOps
    ['https://www.docker.com/', 'Docker', 'Developer-friendly container platform'],
    ['https://kubernetes.io/', 'Kubernetes', 'Production-Grade Container Orchestration'],
    ['https://aws.amazon.com/', 'AWS', 'Amazon Web Services'],
    ['https://cloud.google.com/', 'Google Cloud', 'Google Cloud Platform'],
    ['https://azure.microsoft.com/', 'Microsoft Azure', 'Microsoft Cloud Platform'],
    
    // Frameworks
    ['https://laravel.com/', 'Laravel', 'The PHP Framework For Web Artisans'],
    ['https://symfony.com/', 'Symfony', 'PHP Framework'],
    ['https://laravel.com/docs', 'Laravel Documentation', 'Laravel Documentation'],
    
    // Databases
    ['https://www.mysql.com/', 'MySQL', 'MySQL Database'],
    ['https://www.postgresql.org/', 'PostgreSQL', 'PostgreSQL Database'],
    ['https://www.mongodb.com/', 'MongoDB', 'MongoDB Database'],
    
    // Security
    ['https://owasp.org/', 'OWASP', 'Open Web Application Security Project'],
    
    // Algorithms and Data Structures
    ['https://www.geeksforgeeks.org/', 'GeeksforGeeks', 'A computer science portal for geeks'],
    ['https://www.tutorialspoint.com/', 'TutorialsPoint', 'Tutorials & Interview Questions'],
    
    // Testing
    ['https://junit.org/', 'JUnit', 'Java Testing Framework'],
    ['https://pytest.org/', 'pytest', 'Testing Framework for Python'],
    
    // Mobile Development
    ['https://developer.android.com/', 'Android Developers', 'Android Developers'],
    ['https://developer.apple.com/swift/', 'Swift', 'Swift Programming Language'],
    
    // Game Development
    ['https://unity.com/', 'Unity', 'Unity Real-Time Development Platform'],
    ['https://www.unrealengine.com/', 'Unreal Engine', 'Unreal Engine'],
    
    // Design and UI/UX
    ['https://developer.mozilla.org/en-US/docs/Web/CSS', 'CSS Documentation', 'CSS documentation on MDN'],
    ['https://tailwindcss.com/', 'Tailwind CSS', 'Rapidly build modern websites'],
    
    // Algorithms
    ['https://en.wikipedia.org/wiki/List_of_algorithms', 'Algorithms', 'List of algorithms on Wikipedia'],
    ['https://www.hackerrank.com/', 'HackerRank', 'Practice Coding'],
    
    // AI and Machine Learning
    ['https://www.tensorflow.org/', 'TensorFlow', 'An Open Source Machine Learning Framework'],
    ['https://pytorch.org/', 'PyTorch', 'Tensors and Dynamic neural networks in Python'],
    ['https://scipy.org/', 'SciPy', 'Scientific Computing in Python'],
    
    // Cloud Computing
    ['https://cloud.google.com/python', 'Python on Google Cloud', 'Python on Google Cloud'],
    ['https://aws.amazon.com/developer/language/python/', 'Python on AWS', 'Python on AWS'],
    
    // Competitive Programming
    ['https://leetcode.com/', 'LeetCode', 'Level up your coding skills'],
    ['https://www.hackerearth.com/', 'HackerEarth', 'Programming challenges & hiring solutions'],
    
    // Additional useful programming sites
    ['https://regexr.com/', 'RegExr', 'Learn, Build, & Test RegEx'],
    ['https://jsonformatter.curiousconcept.com/', 'JSON Formatter', 'JSON Formatter and Validator'],
    ['https://www.programiz.com/', 'Programiz', 'Learn to Program'],
    ['https://www.programming-books.io/', 'Programming Books', 'Free Programming Books'],
    ['https://www.tutorialrepublic.com/', 'Tutorial Republic', 'Web Development Tutorials'],
    ['https://www.javatpoint.com/', 'JavaTpoint', 'Programming tutorials'],
];

echo "Starting to populate the database with " . count($resources) . " programming resources...\n";

$addedCount = 0;
$failedCount = 0;

foreach ($resources as $resource) {
    $url = $resource[0];
    $title = $resource[1];
    $description = $resource[2];
    
    // Check if URL already exists
    $checkSql = "SELECT id FROM websites WHERE url = :url";
    $checkStmt = $pdo->prepare($checkSql);
    $checkStmt->bindValue(':url', $url);
    $checkStmt->execute();
    
    if ($checkStmt->rowCount() == 0) {
        // URL doesn't exist, insert new record
        $sql = "INSERT INTO websites (url, title, description, content) VALUES (:url, :title, :description, :content)";
        $stmt = $pdo->prepare($sql);
        
        // Clean and sanitize content before storage
        $cleanContent = preg_replace('/\s+/', ' ', strip_tags($description));
        $cleanContent = preg_replace('/[^a-zA-Z0-9\s\.\,\!\?\-\:\;\(\)\'\"&]/', ' ', $cleanContent);
        $cleanContent = preg_replace('/\s+/', ' ', $cleanContent);
        $cleanContent = trim($cleanContent);
        $cleanContent = substr($cleanContent, 0, 5000);
        
        $stmt->bindValue(':url', $url);
        $stmt->bindValue(':title', $title);
        $stmt->bindValue(':description', $description);
        $stmt->bindValue(':content', $cleanContent);
        
        try {
            $stmt->execute();
            echo "Added: $title - $url\n";
            $addedCount++;
        } catch (PDOException $e) {
            echo "Failed to add: $url - " . $e->getMessage() . "\n";
            $failedCount++;
        }
    } else {
        echo "Skipped (already exists): $url\n";
    }
}

echo "\nDatabase population complete!\n";
echo "Added: $addedCount resources\n";
echo "Failed: $failedCount resources\n";
echo "Total in database: " . $pdo->query("SELECT COUNT(*) FROM websites")->fetchColumn() . " resources\n";

?>