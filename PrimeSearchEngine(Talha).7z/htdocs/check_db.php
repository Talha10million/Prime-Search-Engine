<?php
// check_db.php - Script to check what's in your database

require_once 'db_connect.php';

try {
    // Count total entries
    $countStmt = $pdo->query("SELECT COUNT(*) FROM websites");
    $totalCount = $countStmt->fetchColumn();
    
    echo "<h2>Database Status Check</h2>";
    echo "<p>Total entries in database: <strong>$totalCount</strong></p>";
    
    if ($totalCount > 0) {
        echo "<h3>Recent entries:</h3>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>URL</th><th>Title</th><th>Description</th></tr>";
        
        $recentStmt = $pdo->query("SELECT url, title, description FROM websites ORDER BY id DESC LIMIT 20");
        while ($row = $recentStmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['url']) . "</td>";
            echo "<td>" . htmlspecialchars($row['title']) . "</td>";
            echo "<td>" . htmlspecialchars($row['description']) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='color: red;'><strong>No entries found in the database!</strong></p>";
        echo "<p>Please run the populate script first at: <a href='populate_ui.html'>http://localhost/populate_ui.html</a></p>";
    }
} catch (PDOException $e) {
    echo "<p style='color: red;'>Database error: " . $e->getMessage() . "</p>";
}

?>