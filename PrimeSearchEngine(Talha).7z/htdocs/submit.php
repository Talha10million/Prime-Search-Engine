<?php
// Check if it's a search request (GET with query parameter)
if (isset($_GET['query']) && !empty($_GET['query'])) {
    // This is a search request
    include 'db_connect.php';
    
    $searchQuery = trim($_GET['query']);
    
    // Prepare and execute search query
    try {
        // Search only in title and description fields, not the full content
        $stmt = $pdo->prepare("SELECT DISTINCT url, title, description FROM websites WHERE title LIKE :query OR description LIKE :query OR url LIKE :query ORDER BY id DESC LIMIT 20");
        $stmt->execute(['query' => '%' . $searchQuery . '%']);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Search Results - Prime Search Engine</title>
        <link rel="stylesheet" href="style.css">
        <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3E%3Crect width='16' height='16' fill='%23ff8c00'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-family='Arial Black' font-size='10' fill='white'%3EP%3C/text%3E%3C/svg%3E">
        <style>
            .results-container {
                width: 80%;
                max-width: 1000px;
                margin: 40px auto;
                padding: 20px;
                background: rgba(255, 255, 255, 0.15);
                border-radius: 10px;
                backdrop-filter: blur(10px);
                box-shadow: 0 10px 30px rgba(139, 69, 19, 0.2);
            }
            
            .result-item {
                background: rgba(255, 255, 255, 0.95);
                margin-bottom: 20px;
                padding: 15px;
                border-radius: 8px;
                box-shadow: 0 4px 15px rgba(139, 69, 19, 0.2);
                transition: all 0.3s ease;
            }
            
            .result-item.keyboard-selected {
                background: rgba(255, 140, 0, 0.2);
                box-shadow: 0 0 0 2px rgba(255, 140, 0, 0.8), 0 4px 15px rgba(139, 69, 19, 0.2);
                transform: translateY(-2px);
                border: 1px solid rgba(255, 140, 0, 0.5);
            }
            
            .favicon-icon {
                width: 16px;
                height: 16px;
                margin-right: 8px;
                vertical-align: middle;
                border-radius: 2px;
            }
            
            .result-item {
                position: relative;
                overflow: visible; /* Allow holographic effect to show outside */
            }
            
            .result-item::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                border-radius: 8px;
                border: 1px solid transparent;
                box-shadow: 0 0 0 rgba(255, 140, 0, 0);
                transition: all 0.3s ease;
                pointer-events: none;
                z-index: -1;
            }
            
            .result-item:hover::before {
                border: 1px solid rgba(255, 140, 0, 0.6);
                box-shadow: 0 0 15px rgba(255, 140, 0, 0.4), 0 0 30px rgba(255, 165, 0, 0.2);
                transform: translateY(-3px);
            }
            
            .result-item:hover {
                transform: translateY(-3px) scale(1.01);
            }
            
            /* Dark Mode Styles for Submit Page */
            body.dark-mode {
                background: radial-gradient(ellipse at center, #2c2c2c 0%, #1a1a1a 30%, #0d0d0d 60%, #000000 100%);
            }

            body.dark-mode::before {
                background: 
                    radial-gradient(circle at 20% 30%, rgba(50, 50, 50, 0.15) 0%, transparent 20%),
                    radial-gradient(circle at 80% 70%, rgba(70, 70, 70, 0.15) 0%, transparent 20%),
                    radial-gradient(circle at 40% 80%, rgba(60, 60, 60, 0.15) 0%, transparent 20%),
                    radial-gradient(circle at 70% 20%, rgba(80, 80, 80, 0.15) 0%, transparent 20%);
            }

            body.dark-mode .container {
                color: #f0f0f0;
            }

            body.dark-mode #logo {
                color: #ffffff;
                text-shadow: 0 0 10px rgba(255, 255, 255, 0.7), 0 0 20px rgba(100, 100, 255, 0.5);
            }

            body.dark-mode .slogan {
                color: #e0e0e0;
                text-shadow: 0 0 8px rgba(100, 100, 255, 0.6);
            }

            body.dark-mode #search-input {
                background: rgba(40, 40, 40, 0.95);
                color: #fff;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
                border: 1px solid rgba(100, 100, 100, 0.3);
            }

            body.dark-mode .search-button {
                background: linear-gradient(to bottom, #4a5568, #2d3748);
            }

            body.dark-mode .result-item {
                background: rgba(40, 40, 40, 0.95);
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.4);
            }

            body.dark-mode .result-title a {
                color: #63b3ed;
            }

            body.dark-mode .result-url {
                color: #4fd1c5;
            }

            body.dark-mode .result-desc {
                color: #cbd5e0;
            }

            body.dark-mode .search-info {
                color: #e0e0e0;
            }

            body.dark-mode .search-stats {
                color: #e0e0e0;
                text-shadow: 0 0 5px rgba(100, 100, 255, 0.4);
            }

            body.dark-mode .autocomplete-items {
                background: rgba(30, 30, 30, 0.95);
                border: 1px solid #4a5568;
            }

            body.dark-mode .autocomplete-items div {
                color: #f7fafc;
                border-bottom: 1px solid #4a5568;
            }

            body.dark-mode .autocomplete-items div:hover,
            body.dark-mode .autocomplete-active {
                background-color: #4a5568 !important;
            }

            body.dark-mode .history-container {
                background: rgba(30, 30, 30, 0.95);
                border: 1px solid #4a5568;
            }

            body.dark-mode .history-item {
                color: #f7fafc;
                border-bottom: 1px solid #4a5568;
            }

            body.dark-mode .history-item:hover {
                background-color: #4a5568;
            }

            body.dark-mode .history-header {
                color: #63b3ed;
                border-bottom: 1px solid #63b3ed;
            }

            body.dark-mode .speed-indicator {
                color: #e0e0e0;
                text-shadow: 0 0 5px rgba(100, 100, 255, 0.6);
            }

            /* Parallax Background Elements - now using animated radial gradients instead */
            .parallax-container {
                display: none; /* Hide the old parallax since we're using the new animated background */
            }
            
            .result-item {
                opacity: 0;
                transform: translateY(20px);
                animation: fadeInUp 0.6s forwards;
            }
            
            @keyframes fadeInUp {
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            /* Staggered animation delays */
            .result-item:nth-child(1) { animation-delay: 0.1s; }
            .result-item:nth-child(2) { animation-delay: 0.2s; }
            .result-item:nth-child(3) { animation-delay: 0.3s; }
            .result-item:nth-child(4) { animation-delay: 0.4s; }
            .result-item:nth-child(5) { animation-delay: 0.5s; }
            .result-item:nth-child(6) { animation-delay: 0.6s; }
            .result-item:nth-child(7) { animation-delay: 0.7s; }
            .result-item:nth-child(8) { animation-delay: 0.8s; }
            .result-item:nth-child(9) { animation-delay: 0.9s; }
            .result-item:nth-child(10) { animation-delay: 1.0s; }
            
            .result-title {
                font-size: 1.3rem;
                color: #d2691e;
                margin-bottom: 5px;
            }
            
            .result-url {
                color: #ff8c00;
                font-size: 0.9rem;
                margin-bottom: 5px;
            }
            
            .result-desc {
                color: #333;
                line-height: 1.5;
            }
            
            .search-info {
                text-align: center;
                color: #fff8f0;
                margin: 20px 0;
                font-size: 1.1rem;
                text-shadow: 0 0 5px rgba(255, 140, 0, 0.4);
            }
            
            .search-speed {
                text-align: center;
                color: #fff;
                font-size: 0.9rem;
                margin: 10px 0;
                text-shadow: 0 0 5px rgba(255, 140, 0, 0.6);
            }
            
            .back-button {
                display: block;
                width: 200px;
                margin: 20px auto;
                padding: 10px;
                background: linear-gradient(to bottom, #ff8c00, #ff7f50);
                color: white;
                text-align: center;
                text-decoration: none;
                border-radius: 50px;
                transition: all 0.3s ease;
                border: none;
                font-weight: bold;
                box-shadow: 0 4px 15px rgba(139, 69, 19, 0.3);
            }
            
            .back-button:hover {
                background: linear-gradient(to bottom, #ff7f50, #ff6347);
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(139, 69, 19, 0.4);
            }
        </style>
    </head>
    <body>
        <!-- Dark/Light Mode Toggle -->
        <div class="mode-toggle" id="mode-toggle"></div>
        
        <!-- Feature Links -->
        <div style="position: fixed; top: 20px; left: 20px; z-index: 1000; display: flex; gap: 10px;">
            <a href="dashboard.html" style="background: rgba(255, 140, 0, 0.8); color: white; padding: 8px 15px; border-radius: 20px; text-decoration: none; font-size: 0.9rem; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3); transition: all 0.3s ease;">Dashboard</a>
            <a href="features_hub.html" style="background: rgba(78, 204, 163, 0.8); color: white; padding: 8px 15px; border-radius: 20px; text-decoration: none; font-size: 0.9rem; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3); transition: all 0.3s ease;">Features</a>
        </div>
        
        <!-- Search Result Preview -->
        <div class="result-preview" id="result-preview">
            <div class="result-preview-header">
                <div class="result-preview-title">Preview</div>
                <div class="result-preview-close" id="preview-close">✕</div>
            </div>
            <iframe class="result-preview-content" id="preview-content"></iframe>
        </div>
        
        <div class="parallax-container" id="parallax-container">
            <div class="parallax-layer parallax-layer-1" id="parallax-layer-1"></div>
            <div class="parallax-layer parallax-layer-2" id="parallax-layer-2"></div>
            <div class="parallax-layer parallax-layer-3" id="parallax-layer-3"></div>
        </div>
        
        <div class="container">
            <div class="logo-container">
                <h1 id="logo">PRIME</h1>
                <p class="slogan">Your Premier Search Experience</p>
            </div>
            
            <div class="search-info">
                <p>Search results for: <strong>"<?= htmlspecialchars($searchQuery) ?>"</strong></p>
                <p><?= count($results) ?> results found</p>
            </div>
            
            <div class="search-speed" id="search-speed">
                <?php 
                // Simulate search speed - in a real implementation, you would track query time
                $start_time = microtime(true);
                if (isset($_SERVER['REQUEST_TIME_FLOAT'])) {
                    $time_taken = round((microtime(true) - $_SERVER['REQUEST_TIME_FLOAT']) * 1000, 2);
                    echo "Search took " . $time_taken . "ms";
                } else {
                    // Fallback: show random fast time
                    echo "Search took " . (rand(50, 200)/10) . "ms";
                }
                ?>
            </div>
            
            <div class="results-container">
                <?php if (count($results) > 0): ?>
                    <?php foreach ($results as $index => $result): ?>
                        <?php
                        // Extract domain from URL for favicon
                        $url = parse_url(htmlspecialchars($result['url']));
                        $domain = $url['host'] ?? '';
                        $favicon_url = 'https://' . $domain . '/favicon.ico';
                        ?>
                        <?php
                        // Sanitize description for display to handle any remaining problematic characters
                        $sanitizedDescription = $result['description'];
                        if (strlen($sanitizedDescription) > 0 && !preg_match('/[a-zA-Z]/', $sanitizedDescription)) {
                            // If description doesn't contain letters, it might be corrupted
                            $sanitizedDescription = 'No description available.';
                        } else {
                            // Clean up any problematic characters
                            $sanitizedDescription = preg_replace('/[^a-zA-Z0-9\s\.\,\!\?\-\(\)]/', ' ', $sanitizedDescription);
                            $sanitizedDescription = preg_replace('/\s+/', ' ', $sanitizedDescription);
                            $sanitizedDescription = trim($sanitizedDescription);
                        }
                        ?>
                        <div class="result-item" data-result-index="<?= $index ?>">
                            <div class="result-title">
                                <img src="<?= $favicon_url ?>" alt="Favicon" class="favicon-icon" onerror="this.style.display='none';">
                                <a href="<?= htmlspecialchars($result['url']) ?>" target="_blank" class="result-link">
                                    <?php 
                                    $sanitizedTitle = htmlspecialchars($result['title']);
                                    if (strlen($sanitizedTitle) > 0 && !preg_match('/[a-zA-Z]/', $sanitizedTitle)) {
                                        $sanitizedTitle = 'No Title Available';
                                    }
                                    echo $sanitizedTitle;
                                    ?>
                                </a>
                            </div>
                            <div class="result-url"><?= htmlspecialchars($result['url']) ?></div>
                            <div class="result-desc"><?= htmlspecialchars(substr($sanitizedDescription, 0, 300)) ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="result-item" data-result-index="-1">
                        <div class="result-title">No results found</div>
                        <div class="result-desc">Sorry, we couldn't find any results for "<?= htmlspecialchars($searchQuery) ?>". Try a different search term.</div>
                    </div>
                <?php endif; ?>
            </div>
            
            <a href="index.html" class="back-button" style="text-decoration: none;">Back to Search</a>
        </div>

        <script>
            // Holographic/Neon cursor effects
            document.addEventListener('DOMContentLoaded', function() {
                // Create holographic cursor follower
                const cursorFollower = document.createElement('div');
                cursorFollower.classList.add('cursor-follower');
                document.body.appendChild(cursorFollower);
                
                // Create hover effect
                const cursorHover = document.createElement('div');
                cursorHover.classList.add('cursor-hover');
                document.body.appendChild(cursorHover);
                
                // Track mouse movement for holographic effects
                document.addEventListener('mousemove', (e) => {
                    const x = e.clientX;
                    const y = e.clientY;
                    
                    // Update main cursor position with smooth transition
                    cursorFollower.style.left = `${x}px`;
                    cursorFollower.style.top = `${y}px`;
                    
                    // Create digital particle trail occasionally
                    if (Math.random() > 0.6) {
                        createDigitalParticle(x, y);
                    }
                });
                
                // Function to create a digital particle
                function createDigitalParticle(x, y) {
                    const particle = document.createElement('div');
                    particle.classList.add('cursor-particle');
                    
                    // Random position offset for more organic feel
                    const offsetX = (Math.random() - 0.5) * 30;
                    const offsetY = (Math.random() - 0.5) * 30;
                    
                    particle.style.left = `${x + offsetX}px`;
                    particle.style.top = `${y + offsetY}px`;
                    
                    // Random size
                    const size = 3 + Math.random() * 5;
                    particle.style.width = `${size}px`;
                    particle.style.height = `${size}px`;
                    
                    // Random color variation
                    const hue = 35 + Math.random() * 10; // Orange range
                    particle.style.background = `hsla(${hue}, 100%, 70%, ${0.6 + Math.random() * 0.4})`;
                    
                    document.body.appendChild(particle);
                    
                    // Set CSS variables for animation
                    const tx = (Math.random() - 0.5) * 100;
                    const ty = (Math.random() - 0.5) * 100;
                    particle.style.setProperty('--tx', `${tx}px`);
                    particle.style.setProperty('--ty', `${ty}px`);
                    
                    // Remove particle after animation completes
                    setTimeout(() => {
                        particle.remove();
                    }, 1500);
                }
                
                // Add hover effect to interactive elements
                const interactiveElements = document.querySelectorAll('button, a, input, .logo-container, .search-button');
                interactiveElements.forEach(element => {
                    element.addEventListener('mouseenter', () => {
                        cursorHover.classList.add('active');
                        cursorHover.style.left = `${element.getBoundingClientRect().left + element.offsetWidth/2}px`;
                        cursorHover.style.top = `${element.getBoundingClientRect().top + element.offsetHeight/2}px`;
                    });
                    
                    element.addEventListener('mouseleave', () => {
                        cursorHover.classList.remove('active');
                    });
                    
                    // Update hover position on mousemove over interactive elements
                    element.addEventListener('mousemove', (e) => {
                        if (cursorHover.classList.contains('active')) {
                            cursorHover.style.left = `${e.clientX}px`;
                            cursorHover.style.top = `${e.clientY}px`;
                        }
                    });
                });
                
                // Logo slash animation - Venom-like alphabet slice effect
                const logo = document.getElementById('logo');
                const slash = document.createElement('div');
                slash.classList.add('slash');
                slash.id = 'slash';
                slash.style.opacity = '0';
                slash.style.transition = 'opacity 0.3s ease, transform 0.5s ease';
                
                const slashEffect = document.createElement('div');
                slashEffect.classList.add('slash-effect');
                slashEffect.appendChild(slash);
                logo.parentNode.appendChild(slashEffect);
                
                // Create the split effect elements
                const logoText = logo.textContent;
                const logoChars = logoText.split('');
                logo.innerHTML = '';
                
                logoChars.forEach((char, index) => {
                    const charSpan = document.createElement('span');
                    charSpan.textContent = char;
                    charSpan.style.display = 'inline-block';
                    charSpan.style.transition = 'transform 0.4s ease, opacity 0.4s ease, color 0.4s ease';
                    charSpan.classList.add('logo-char');
                    logo.appendChild(charSpan);
                });
                
                logo.addEventListener('mouseover', () => {
                    // Apply venom-like alphabet slice effect
                    const chars = logo.querySelectorAll('.logo-char');
                    
                    chars.forEach((char, index) => {
                        // Create a unique animation for each character
                        setTimeout(() => {
                            // Random direction for each character
                            const direction = Math.random() > 0.5 ? 1 : -1;
                            const distance = 15 + Math.random() * 10; // Random distance between 15-25px
                            const rotation = (Math.random() * 20) - 10; // Random rotation between -10 and 10 degrees
                            
                            char.style.transform = `translateX(${direction * distance}px) translateY(${(Math.random() * 10) - 5}px) rotate(${rotation}deg)`;
                            char.style.opacity = '0.7';
                            char.style.color = '#ff8c00'; // Orange color during split
                        }, index * 50); // Stagger the animation for each character
                    });
                    
                    // Show slash effect
                    slash.style.opacity = '0.7';
                    slash.style.transform = 'rotate(-30deg) translateX(100%)';
                });
                
                logo.addEventListener('mouseout', () => {
                    // Reset to original position with glue effect
                    const chars = logo.querySelectorAll('.logo-char');
                    
                    chars.forEach((char, index) => {
                        setTimeout(() => {
                            char.style.transform = 'translateX(0) translateY(0) rotate(0deg)';
                            char.style.opacity = '1';
                            char.style.color = '#ffffff'; // Restore original color
                        }, index * 50); // Stagger the return animation
                    });
                    
                    // Hide slash effect
                    slash.style.opacity = '0';
                    slash.style.transform = 'rotate(-30deg) translateX(-50%)';
                });
            });
        </script>
        <script>
            // Populate parallax layers with search-related symbols
            document.addEventListener('DOMContentLoaded', function() {
                const layer1 = document.getElementById('parallax-layer-1');
                const layer2 = document.getElementById('parallax-layer-2');
                const layer3 = document.getElementById('parallax-layer-3');
                
                // Symbols for parallax layers
                const symbols = ['🔍', '📋', '📊', '🔗', '🎯', '💡', '📌', '🌐', '🚀', '⭐'];
                
                // Add elements to layer 1
                for (let i = 0; i < 15; i++) {
                    const element = document.createElement('div');
                    element.textContent = symbols[Math.floor(Math.random() * symbols.length)];
                    element.style.position = 'relative';
                    element.style.left = `${Math.random() * 100}%`;
                    element.style.top = `${Math.random() * 100}%`;
                    element.style.opacity = '0.7';
                    layer1.appendChild(element);
                }
                
                // Add elements to layer 2
                for (let i = 0; i < 10; i++) {
                    const element = document.createElement('div');
                    element.textContent = symbols[Math.floor(Math.random() * symbols.length)];
                    element.style.position = 'relative';
                    element.style.left = `${Math.random() * 100}%`;
                    element.style.top = `${Math.random() * 100}%`;
                    element.style.opacity = '0.5';
                    layer2.appendChild(element);
                }
                
                // Add elements to layer 3
                for (let i = 0; i < 5; i++) {
                    const element = document.createElement('div');
                    element.textContent = symbols[Math.floor(Math.random() * symbols.length)];
                    element.style.position = 'relative';
                    element.style.left = `${Math.random() * 100}%`;
                    element.style.top = `${Math.random() * 100}%`;
                    element.style.opacity = '0.3';
                    layer3.appendChild(element);
                }
                
                // Parallax background effect
                document.addEventListener('mousemove', (e) => {
                    const container = document.getElementById('parallax-container');
                    if (!container) return;
                    
                    const x = (e.clientX / window.innerWidth) * 100;
                    const y = (e.clientY / window.innerHeight) * 100;
                    
                    // Move layers at different speeds for parallax effect
                    layer1.style.transform = `translate(${x * 0.02}px, ${y * 0.02}px)`;
                    layer2.style.transform = `translate(${x * 0.04}px, ${y * 0.04}px)`;
                    layer3.style.transform = `translate(${x * 0.06}px, ${y * 0.06}px)`;
                });
            });
        </script>
    </body>
    </html>
    <?php
    exit(); // Stop execution after processing the search
} else {
    // This is a site submission request (POST)
    $message = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $url = trim($_POST['url']);

        if (empty($url)) {
            $message = 'Please enter a URL.';
        } elseif (!filter_var($url, FILTER_VALIDATE_URL)) {
            $message = 'Please enter a valid URL.';
        } else {
            try {
                require_once 'db_connect.php';

                // Comprehensive web page fetching with proper encoding and content type handling
                $html = '';
                $contentType = '';
                
                // Try cURL first (more reliable than file_get_contents for external sites)
                if (function_exists('curl_init')) {
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
                    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
                    curl_setopt($ch, CURLOPT_ENCODING, '');
                    curl_setopt($ch, CURLOPT_HEADER, 0); // Don't include headers in output
                    curl_setopt($ch, CURLOPT_NOBODY, false); // Include body in output
                    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
                    
                    $html = curl_exec($ch);
                    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
                    
                    if (curl_errno($ch) || $httpCode >= 400) {
                        $html = false;
                    }
                    
                    curl_close($ch);
                }
                
                // Check if the content is actually HTML before processing
                if ($html && $contentType) {
                    // Only process if content type indicates HTML
                    if (strpos($contentType, 'text/html') === false && strpos($contentType, 'application/xhtml') === false) {
                        // Not HTML content, don't try to parse it
                        $html = '';
                    }
                }
                
                // Fallback to file_get_contents if cURL fails
                if ($html === false || $html === '') {
                    // Use stream context that mimics browser behavior better
                    $context = stream_context_create([
                        'http' => [
                            'timeout' => 15,
                            'user_agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                            'header' => [
                                'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language: en-US,en;q=0.5',
                                'Accept-Encoding: gzip, deflate',
                                'Connection: keep-alive',
                            ]
                        ]
                    ]);
                    $html = @file_get_contents($url, false, $context);
                    
                    // If content looks like HTML, continue processing
                    if ($html && strlen($html) > 0) {
                        // Look for HTML indicators, not just '<' 
                        $isHtml = (stripos($html, '<html') !== false || 
                                  stripos($html, '<head') !== false || 
                                  stripos($html, '<body') !== false || 
                                  (substr_count($html, '<') > 5)); // At least 5 HTML tags
                        if (!$isHtml) {
                            $html = '';
                        }
                    }
                }
                
                // Clean up the content to ensure valid UTF-8
                if ($html) {
                    // Remove any null bytes and control characters that aren't whitespace
                    $html = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $html);
                    
                    // If we can detect encoding properly, convert to UTF-8
                    if (function_exists('mb_check_encoding') && !mb_check_encoding($html, 'UTF-8')) {
                        $encoding = mb_detect_encoding($html, ['UTF-8', 'ISO-8859-1', 'Windows-1252', 'ASCII'], true);
                        if ($encoding && $encoding !== 'UTF-8') {
                            $html = mb_convert_encoding($html, 'UTF-8', $encoding);
                        } else {
                            // If detection fails, try to clean the string
                            $html = mb_convert_encoding($html, 'UTF-8', 'UTF-8');
                        }
                    }
                    
                    // Final validation - ensure it's mostly readable text
                    $textRatio = 0;
                    if (strlen($html) > 0) {
                        $textChars = preg_match_all('/[a-zA-Z0-9\s]/', $html);
                        $textRatio = $textChars / strlen($html);
                    }
                    
                    // If less than 30% of characters are readable text, it might be corrupted
                    if ($textRatio < 0.3) {
                        $html = '';
                    }
                }

                if ($html === false || $html === '') {
                    $title = 'Title could not be fetched';
                    $description = 'Description could not be fetched.';
                } else {
                    // Extract Title (try multiple patterns)
                    $title = 'No Title Found';
                    if (preg_match('/<title[^>]*>(.*?)<\/title>/i', $html, $matches)) {
                        $title = trim(strip_tags($matches[1]));
                    } elseif (preg_match('/<h1[^>]*>(.*?)<\/h1>/i', $html, $matches)) {
                        $title = trim(strip_tags($matches[1]));
                    }
                    
                    // Extract Meta Description (try multiple patterns)
                    $description = 'No description found.';
                    if (preg_match('/<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']*)["\']/i', $html, $matches)) {
                        $description = trim(strip_tags($matches[1]));
                    } elseif (preg_match('/<meta[^>]+content=["\']([^"\']*)["\'][^>]+name=["\']description["\']/i', $html, $matches)) {
                        $description = trim(strip_tags($matches[1]));
                    } elseif (preg_match('/<meta[^>]+property=["\']og:description["\'][^>]+content=["\']([^"\']*)["\']/i', $html, $matches)) {
                        $description = trim(strip_tags($matches[1]));
                    }
                    
                    // If no description found, extract first 150 characters from body, ensuring it's clean text
                    if ($description === 'No description found.' || trim($description) === '') {
                        // Extract body content, but be more careful about it
                        $bodyMatch = [];
                        if (preg_match('/<body[^>]*>(.*?)<\/body>/is', $html, $bodyMatch)) {
                            $bodyText = preg_replace('/\s+/', ' ', strip_tags($bodyMatch[1]));
                            // Only take the first meaningful sentence or 150 chars
                            $bodyText = substr($bodyText, 0, 300);
                            // Ensure we don't get weird characters
                            $bodyText = preg_replace('/[^a-zA-Z0-9\s\.\,\!\?\-]/', ' ', $bodyText);
                            $bodyText = trim(preg_replace('/\s+/', ' ', $bodyText));
                            $description = substr($bodyText, 0, 150) . (strlen($bodyText) > 150 ? '...' : '');
                        }
                    }
                    
                    // Final cleanup of description to ensure it's readable text
                    $description = trim($description);
                    if (strlen($description) > 0 && !preg_match('/[a-zA-Z]/', $description)) {
                        // If description doesn't contain any letters, it's likely not proper text
                        $description = 'No description found.';
                    }
                }

                // Check if URL already exists in database to prevent duplicates
                $checkSql = "SELECT id FROM websites WHERE url = :url";
                $checkStmt = $pdo->prepare($checkSql);
                $checkStmt->bindValue(':url', $url);
                $checkStmt->execute();
                
                if ($checkStmt->rowCount() == 0) {
                    // URL doesn't exist, insert new record
                    $sql = "INSERT INTO websites (url, title, description, content) VALUES (:url, :title, :description, :content)";
                    $stmt = $pdo->prepare($sql);
                    
                    $stmt->bindValue(':url', $url);
                    $stmt->bindValue(':title', $title);
                    $stmt->bindValue(':description', $description);
                    // Clean and sanitize content before storage - comprehensive sanitization
                $cleanContent = '';
                if ($html) {
                    // Strip HTML tags and normalize whitespace
                    $cleanContent = preg_replace('/\s+/', ' ', strip_tags($html));
                    // Remove any non-printable characters except common punctuation
                    $cleanContent = preg_replace('/[^a-zA-Z0-9\s\.\,\!\?\-\:\;\(\)\'\"&]/', ' ', $cleanContent);
                    // Remove excessive spaces
                    $cleanContent = preg_replace('/\s+/', ' ', $cleanContent);
                    $cleanContent = trim($cleanContent);
                    // Limit to 5000 characters
                    $cleanContent = substr($cleanContent, 0, 5000);
                }
                $stmt->bindValue(':content', $cleanContent);

                    $stmt->execute();
                } else {
                    // URL already exists, update the existing record
                    $updateSql = "UPDATE websites SET title = :title, description = :description, content = :content WHERE url = :url";
                    $updateStmt = $pdo->prepare($updateSql);
                    
                    $updateStmt->bindValue(':url', $url);
                    $updateStmt->bindValue(':title', $title);
                    $updateStmt->bindValue(':description', $description);
                    // Clean and sanitize content before storage - comprehensive sanitization
                    $cleanContent = '';
                    if ($html) {
                        // Strip HTML tags and normalize whitespace
                        $cleanContent = preg_replace('/\s+/', ' ', strip_tags($html));
                        // Remove any non-printable characters except common punctuation
                        $cleanContent = preg_replace('/[^a-zA-Z0-9\s\.\,\!\?\-\:\;\(\)\'\"&]/', ' ', $cleanContent);
                        // Remove excessive spaces
                        $cleanContent = preg_replace('/\s+/', ' ', $cleanContent);
                        $cleanContent = trim($cleanContent);
                        // Limit to 5000 characters
                        $cleanContent = substr($cleanContent, 0, 5000);
                    }
                    $updateStmt->bindValue(':content', $cleanContent);
                    
                    $updateStmt->execute();
                }

                $message = 'Thank you! The site has been submitted and added to the index.';

            } catch (Exception $e) {
                $message = 'An error occurred: ' . $e->getMessage();
            }
        }
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Submit a Site - Prime Search Engine</title>
        <link rel="stylesheet" href="style.css">
        <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3E%3Crect width='16' height='16' fill='%23ff8c00'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-family='Arial Black' font-size='10' fill='white'%3EP%3C/text%3E%3C/svg%3E">
    </head>
    <body>
        <div class="parallax-container" id="parallax-container">
            <div class="parallax-layer parallax-layer-1" id="parallax-layer-1"></div>
            <div class="parallax-layer parallax-layer-2" id="parallax-layer-2"></div>
            <div class="parallax-layer parallax-layer-3" id="parallax-layer-3"></div>
        </div>
        
        <div class="container">
            <div class="logo-container">
                <h1 id="logo">PRIME</h1>
                <p class="slogan">Your Premier Search Experience</p>
            </div>

            <div style="width: 60%; max-width: 700px; margin-top: 30px;">
                <h2>Submit a New Site</h2>
                <p>Submit a URL to add it to our search index. The system will attempt to automatically fetch the title and description.</p>
                
                <?php if ($message): ?>
                    <p style="color: #fff; padding: 10px; background: rgba(92, 77, 177, 0.5); border-radius: 5px;"><?= htmlspecialchars($message) ?></p>
                <?php endif; ?>

                <form action="submit.php" method="post" class="search-form" style="margin-top: 20px;">
                    <input type="text" name="url" class="search-input" style="width: 100%; padding: 15px; font-size: 1rem; border: none; border-radius: 50px; box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2); outline: none; background: rgba(255, 255, 255, 0.9);" placeholder="https://example.com">
                    <button type="submit" style="margin-top: 15px; width: 100%; padding: 15px; background: #5c4db1; color: white; border: none; border-radius: 50px; font-size: 1.1rem; cursor: pointer; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); transition: all 0.3s ease;">Submit Site</button>
                </form>
                
                <div style="margin-top: 30px; text-align: center;">
                    <a href="index.html" style="color: white; text-decoration: none; padding: 10px 20px; background: #5c4db1; border-radius: 5px; display: inline-block;">Back to Search</a>
                </div>
            </div>
        </div>
    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const title = document.querySelector('#logo');
        if (title) {
            const text = title.textContent.trim();
            const chars = text.split('').map(char => `<span class="char">${char}</span>`).join('');
            title.innerHTML = chars;

            title.addEventListener('click', (e) => {
                if (e.target.classList.contains('char')) {
                    e.target.classList.add('animate');
                    e.target.addEventListener('animationend', () => {
                        e.target.classList.remove('animate');
                    }, { once: true });
                }
            });
        }
    });
    </script>
    <script>
        // Enhanced cursor effects
        document.addEventListener('DOMContentLoaded', function() {
            // Create containers for enhanced cursor effects
            const cursorTrail = document.createElement('div');
            cursorTrail.classList.add('cursor-trail');
            cursorTrail.style.display = 'none';
            document.body.appendChild(cursorTrail);
            
            const magneticCursor = document.createElement('div');
            magneticCursor.classList.add('magnetic-cursor');
            magneticCursor.style.display = 'none';
            document.body.appendChild(magneticCursor);
            
            // Track mouse movement for enhanced effects
            document.addEventListener('mousemove', (e) => {
                const x = e.clientX;
                const y = e.clientY;
                
                // Update trail cursor position
                cursorTrail.style.left = `${x}px`;
                cursorTrail.style.top = `${y}px`;
                cursorTrail.style.display = 'block';
                
                // Create a new trail particle occasionally
                if (Math.random() > 0.7) {
                    createTrailParticle(x, y);
                }
                
                // Update magnetic cursor if active
                if (magneticCursor.style.display === 'block') {
                    magneticCursor.style.left = `${x}px`;
                    magneticCursor.style.top = `${y}px`;
                }
            });
            
            // Function to create a trail particle
            function createTrailParticle(x, y) {
                const trailParticle = document.createElement('div');
                trailParticle.style.position = 'fixed';
                trailParticle.style.left = `${x}px`;
                trailParticle.style.top = `${y}px`;
                trailParticle.style.width = '6px';
                trailParticle.style.height = '6px';
                trailParticle.style.borderRadius = '50%';
                trailParticle.style.background = `rgba(255, ${140 + Math.floor(Math.random() * 50)}, ${50 + Math.floor(Math.random() * 50)}, 0.7)`;
                trailParticle.style.pointerEvents = 'none';
                trailParticle.style.zIndex = '9997';
                document.body.appendChild(trailParticle);
                
                // Animate the particle
                const animation = trailParticle.animate([
                    { 
                        transform: 'scale(1)', 
                        opacity: 1 
                    },
                    { 
                        transform: `translate(${(Math.random() - 0.5) * 40}px, ${(Math.random() - 0.5) * 40}px) scale(0.2)`, 
                        opacity: 0 
                    }
                ], {
                    duration: 800,
                    easing: 'cubic-bezier(0, 0.9, 0.57, 1)'
                });
                
                animation.onfinish = () => {
                    trailParticle.remove();
                };
            }
            
            // Add magnetic effect to interactive elements
            const interactiveElements = document.querySelectorAll('button, a, input, .logo-container, .search-button');
            interactiveElements.forEach(element => {
                element.addEventListener('mouseenter', () => {
                    magneticCursor.style.display = 'block';
                    magneticCursor.classList.add('active');
                });
                
                element.addEventListener('mouseleave', () => {
                    magneticCursor.classList.remove('active');
                    setTimeout(() => {
                        if (!isOverInteractiveElement()) {
                            magneticCursor.style.display = 'none';
                        }
                    }, 300);
                });
            });
            
            // Check if cursor is over any interactive element
            function isOverInteractiveElement() {
                const event = window.event;
                const elements = document.querySelectorAll('button, a, input, .logo-container, .search-button');
                for (let element of elements) {
                    const rect = element.getBoundingClientRect();
                    if (rect.left <= event.clientX && 
                        event.clientX <= rect.right &&
                        rect.top <= event.clientY && 
                        event.clientY <= rect.bottom) {
                        return true;
                    }
                }
                return false;
            }
        });
    </script>
        <script>
            // Populate parallax layers with search-related symbols
            document.addEventListener('DOMContentLoaded', function() {
                const layer1 = document.getElementById('parallax-layer-1');
                const layer2 = document.getElementById('parallax-layer-2');
                const layer3 = document.getElementById('parallax-layer-3');
                
                // Symbols for parallax layers
                const symbols = ['🔍', '📋', '📊', '🔗', '🎯', '💡', '📌', '🌐', '🚀', '⭐'];
                
                // Add elements to layer 1
                for (let i = 0; i < 15; i++) {
                    const element = document.createElement('div');
                    element.textContent = symbols[Math.floor(Math.random() * symbols.length)];
                    element.style.position = 'relative';
                    element.style.left = `${Math.random() * 100}%`;
                    element.style.top = `${Math.random() * 100}%`;
                    element.style.opacity = '0.7';
                    layer1.appendChild(element);
                }
                
                // Add elements to layer 2
                for (let i = 0; i < 10; i++) {
                    const element = document.createElement('div');
                    element.textContent = symbols[Math.floor(Math.random() * symbols.length)];
                    element.style.position = 'relative';
                    element.style.left = `${Math.random() * 100}%`;
                    element.style.top = `${Math.random() * 100}%`;
                    element.style.opacity = '0.5';
                    layer2.appendChild(element);
                }
                
                // Add elements to layer 3
                for (let i = 0; i < 5; i++) {
                    const element = document.createElement('div');
                    element.textContent = symbols[Math.floor(Math.random() * symbols.length)];
                    element.style.position = 'relative';
                    element.style.left = `${Math.random() * 100}%`;
                    element.style.top = `${Math.random() * 100}%`;
                    element.style.opacity = '0.3';
                    layer3.appendChild(element);
                }
                
                // Parallax background effect
                document.addEventListener('mousemove', (e) => {
                    const container = document.getElementById('parallax-container');
                    if (!container) return;
                    
                    const x = (e.clientX / window.innerWidth) * 100;
                    const y = (e.clientY / window.innerHeight) * 100;
                    
                    // Move layers at different speeds for parallax effect
                    layer1.style.transform = `translate(${x * 0.02}px, ${y * 0.02}px)`;
                    layer2.style.transform = `translate(${x * 0.04}px, ${y * 0.04}px)`;
                    layer3.style.transform = `translate(${x * 0.06}px, ${y * 0.06}px)`;
                });
            });
            
            // Animate results on page load
            document.addEventListener('DOMContentLoaded', () => {
                // Add animation class after a short delay to ensure CSS is loaded
                setTimeout(() => {
                    const resultItems = document.querySelectorAll('.result-item');
                    resultItems.forEach(item => {
                        // Each item will animate based on its CSS animation-delay
                        item.style.animationPlayState = 'running';
                    });
                }, 100);
            });
            
            // Keyboard navigation for search results
            let currentSelectedIndex = -1;
            const resultItems = document.querySelectorAll('.result-item');
            
            document.addEventListener('keydown', (e) => {
                // Only process if results exist and they're not the "no results" case
                if (resultItems.length <= 1 || resultItems[0].dataset.resultIndex === "-1") {
                    return;
                }
                
                if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    // Move to next result
                    currentSelectedIndex = (currentSelectedIndex + 1) % resultItems.length;
                    updateSelection();
                } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    // Move to previous result
                    currentSelectedIndex = (currentSelectedIndex - 1 + resultItems.length) % resultItems.length;
                    updateSelection();
                } else if (e.key === 'Enter') {
                    e.preventDefault();
                    // Activate the selected result
                    if (currentSelectedIndex >= 0) {
                        const selectedLink = resultItems[currentSelectedIndex].querySelector('.result-link');
                        if (selectedLink) {
                            selectedLink.click();
                        }
                    }
                } else if (e.key === 'Escape') {
                    // Deselect current selection
                    if (currentSelectedIndex >= 0) {
                        resultItems[currentSelectedIndex].classList.remove('keyboard-selected');
                        currentSelectedIndex = -1;
                    }
                }
            });
            
            function updateSelection() {
                // Remove highlight from all items
                resultItems.forEach(item => {
                    item.classList.remove('keyboard-selected');
                });
                
                // Highlight the current item
                if (currentSelectedIndex >= 0 && currentSelectedIndex < resultItems.length) {
                    resultItems[currentSelectedIndex].classList.add('keyboard-selected');
                    
                    // Scroll to keep the selected item in view
                    resultItems[currentSelectedIndex].scrollIntoView({
                        behavior: 'smooth',
                        block: 'nearest'
                    });
                }
            }
        </script>
        
        <script>
            // Dark/Light Mode Toggle
            document.addEventListener('DOMContentLoaded', function() {
                const modeToggle = document.getElementById('mode-toggle');
                const currentMode = localStorage.getItem('colorMode') || 'light';
                
                if (currentMode === 'dark') {
                    document.body.classList.add('dark-mode');
                    modeToggle.classList.add('dark-mode');
                }
                
                modeToggle.addEventListener('click', function() {
                    document.body.classList.toggle('dark-mode');
                    modeToggle.classList.toggle('dark-mode');
                    
                    const isDarkMode = document.body.classList.contains('dark-mode');
                    localStorage.setItem('colorMode', isDarkMode ? 'dark' : 'light');
                });
            });
            
            // Search Result Preview
            document.addEventListener('DOMContentLoaded', function() {
                const preview = document.getElementById('result-preview');
                const previewContent = document.getElementById('preview-content');
                const previewTitle = document.querySelector('.result-preview-title');
                const previewClose = document.getElementById('preview-close');
                let previewTimeout;
                
                // Close preview when close button is clicked
                previewClose.addEventListener('click', function() {
                    preview.style.opacity = '0';
                    setTimeout(() => {
                        preview.style.display = 'none';
                    }, 300);
                });
                
                // Close preview when clicking outside
                document.addEventListener('click', function(e) {
                    if (!preview.contains(e.target) && 
                        !e.target.closest('.result-item') &&
                        e.target.id !== 'preview-close') {
                        preview.style.opacity = '0';
                        setTimeout(() => {
                            preview.style.display = 'none';
                        }, 300);
                    }
                });
                
                // Simpler preview implementation
                function initPreview() {
                    // Simple preview initialization
                    const resultLinks = document.querySelectorAll('a');
                    console.log('Found ' + resultLinks.length + ' total links on page');
                    
                    for (let i = 0; i < resultLinks.length; i++) {
                        const link = resultLinks[i];
                        // Look for links that are likely search results
                        if (link.closest('.result-item')) {
                            console.log('Found result link: ' + link.textContent);
                            
                            // Add preview on hover
                            link.addEventListener('mouseenter', function() {
                                const url = this.href;
                                const title = this.textContent || 'Preview';
                                
                                // Set preview content
                                document.querySelector('.result-preview-title').textContent = title;
                                document.getElementById('preview-content').src = 'simple_preview.php?url=' + encodeURIComponent(url);
                                
                                // Position preview
                                const rect = this.getBoundingClientRect();
                                const preview = document.getElementById('result-preview');
                                preview.style.left = (rect.right + 20) + 'px';
                                preview.style.top = rect.top + 'px';
                                
                                // Show preview with fade in
                                preview.style.display = 'block';
                                setTimeout(() => {
                                    preview.style.opacity = '1';
                                }, 10);
                            });
                            
                            link.addEventListener('mouseleave', function() {
                                // Hide preview with fade out
                                const preview = document.getElementById('result-preview');
                                preview.style.opacity = '0';
                                setTimeout(() => {
                                    preview.style.display = 'none';
                                }, 300);
                            });
                        }
                    }
                }
                
                // Initialize when page is loaded
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', initPreview);
                } else {
                    initPreview();
                }
            });
        </script>
    </body>
    </html>
    <?php
}
?>