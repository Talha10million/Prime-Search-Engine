<?php
// cleanup_and_update_creator.php - Clean up and properly update creator info

require_once 'db_connect.php';

echo "<h2>Cleaning Up Old Entries and Updating Creator Info</h2>";

// Delete any entries with placeholder URLs
$deleteSql = "DELETE FROM websites WHERE url LIKE '%your-personal-site.com%' OR url LIKE '%placeholder%' OR url LIKE '%example.com%'";
$deletedCount = $pdo->exec($deleteSql); // Use exec() for DELETE operations

echo "<p>Deleted $deletedCount old placeholder entries.</p>";

// Now add our updated entries with the correct URLs
$creatorEntries = [
    [
        'url' => 'https://github.com/Talha10million',
        'title' => 'Prime Search Engine Creator - Muhammad Talha (Shadow Emperor)',
        'description' => 'Meet Muhammad Talha (Shadow Emperor), the developer behind Prime Search Engine - a futuristic search platform with advanced visual effects.',
        'content' => 'Prime Search Engine was created by Muhammad Talha, also known as Shadow Emperor. He is a passionate computer science student and cybersecurity enthusiast who developed Prime as an innovative search platform. The engine features holographic cursors, parallax backgrounds, dynamic search results, keyboard navigation, dark/light mode, and many other advanced features.'
    ],
    [
        'url' => 'https://linkedin.com/in/muhammad-talha',
        'title' => 'About Prime Search Engine - A Project by Muhammad Talha',
        'description' => 'Prime is not just another search engine — it\'s designed with simplicity, performance, and innovation in mind by Muhammad Talha (Shadow Emperor).',
        'content' => 'Prime Search Engine is a cutting-edge search platform designed for modern web browsing. Created by Muhammad Talha (Shadow Emperor), it features holographic cursor effects, parallax backgrounds, keyboard navigation, dark/light mode, search result animations, and more. Prime aims to grow into a multi-functional platform, connecting users with information in smarter ways.'
    ],
    [
        'url' => 'https://instagram.com/talha10million',
        'title' => 'Muhammad Talha (Shadow Emperor) - Developer Portfolio',
        'description' => 'Cybersecurity enthusiast and developer behind Prime Search Engine. Specializing in PHP, C++, cybersecurity, and AI projects.',
        'content' => 'Muhammad Talha (Shadow Emperor) is a computer science student and cybersecurity enthusiast passionate about building futuristic technology projects. Currently interning at Skeler Security, he specializes in PHP/MySQL, C++ programming, and AI-driven projects. His portfolio includes Prime Search Engine, a Hybrid Quantum-Driven Interstellar Management System, and various custom management systems.'
    ],
    [
        'url' => 'https://github.com/Talha10million?tab=projects',
        'title' => 'Prime Creator Projects - Muhammad Talha',
        'description' => 'Explore projects by Muhammad Talha (Shadow Emperor) including Prime Search Engine and other innovative systems.',
        'content' => 'Projects by Muhammad Talha (Shadow Emperor) include Prime Search Engine - a futuristic search platform with holographic effects, a Hybrid Quantum-Driven Interstellar Management System exploring quantum-inspired system design, various custom-built management systems, and C++ learning projects. He also explores AI-driven projects and search systems.'
    ],
    [
        'url' => 'https://github.com/Talha10million',
        'title' => 'Connect with Prime Creator - Muhammad Talha (Shadow Emperor)',
        'description' => 'Connect with Muhammad Talha (Shadow Emperor), the creator of Prime Search Engine, via GitHub, LinkedIn, Instagram, or Discord.',
        'content' => 'Connect with Muhammad Talha (Shadow Emperor), the creator of Prime Search Engine: GitHub: github.com/Talha10million, LinkedIn: Muhammad Talha, Instagram: @talha10million, Discord: talha10millionx. Email: talhaxworks@gmail.com. He is a cybersecurity enthusiast and developer passionate about building futuristic technology projects.'
    ]
];

$addedCount = 0;

foreach ($creatorEntries as $entry) {
    // Check if similar entry already exists (using a more flexible match)
    $checkSql = "SELECT id FROM websites WHERE title = :title";
    $checkStmt = $pdo->prepare($checkSql);
    $checkStmt->bindValue(':title', $entry['title']);
    $checkStmt->execute();
    
    if ($checkStmt->rowCount() == 0) {
        // Insert new entry
        $insertSql = "INSERT INTO websites (url, title, description, content) VALUES (:url, :title, :description, :content)";
        $insertStmt = $pdo->prepare($insertSql);
        
        $insertStmt->bindValue(':url', $entry['url']);
        $insertStmt->bindValue(':title', $entry['title']);
        $insertStmt->bindValue(':description', $entry['description']);
        $insertStmt->bindValue(':content', substr($entry['content'], 0, 5000));
        
        if ($insertStmt->execute()) {
            $addedCount++;
            echo "<p style='color: green;'>✓ Added: " . htmlspecialchars($entry['title']) . "</p>";
        } else {
            echo "<p style='color: red;'>✗ Failed to add: " . htmlspecialchars($entry['title']) . "</p>";
        }
    } else {
        echo "<p>✓ Entry already exists: " . htmlspecialchars($entry['title']) . "</p>";
    }
}

echo "<h3>Process Complete!</h3>";
echo "<p>Now run your search again for 'Creator of Prime Search Engine' - you should see updated URLs without the placeholder.</p>";

// Show current count
$countStmt = $pdo->query("SELECT COUNT(*) FROM websites");
$totalCount = $countStmt->fetchColumn();
echo "<p><strong>Total entries in database: $totalCount</strong></p>";

?>