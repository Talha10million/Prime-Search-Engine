<?php
// find_and_clean_placeholders.php - Find any remaining placeholder entries

require_once 'db_connect.php';

// Find entries with placeholder URLs regardless of title
$findSql = "SELECT id, url, title FROM websites WHERE url LIKE '%your-personal-site.com%' OR url LIKE '%example.com%' OR url LIKE '%placeholder%'";
$findStmt = $pdo->prepare($findSql);
$findStmt->execute();
$results = $findStmt->fetchAll(PDO::FETCH_ASSOC);

if (count($results) > 0) {
    echo "<h3>Found " . count($results) . " entries with placeholder URLs:</h3>";
    foreach ($results as $row) {
        echo "ID: " . $row['id'] . " | URL: " . htmlspecialchars($row['url']) . " | Title: " . htmlspecialchars($row['title']) . "<br>";
    }
    
    // Delete them
    $deleteSql = "DELETE FROM websites WHERE url LIKE '%your-personal-site.com%' OR url LIKE '%example.com%' OR url LIKE '%placeholder%'";
    $deletedCount = $pdo->exec($deleteSql);
    echo "<p><strong>Deleted $deletedCount placeholder entries.</strong></p>";
} else {
    echo "<h3>No placeholder entries found!</h3>";
}

// Now run a fresh search for "Creator of Prime Search Engine"
$searchSql = "SELECT url, title, description FROM websites WHERE title LIKE '%Creator of Prime Search Engine%' OR title LIKE '%Prime creator%' OR title LIKE '%Muhammad Talha%' ORDER BY id DESC LIMIT 10";
$searchStmt = $pdo->prepare($searchSql);
$searchStmt->execute();
$searchResults = $searchStmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h3>Current search results for 'Creator of Prime Search Engine':</h3>";
echo "<table border='1' style='border-collapse: collapse;'>";
echo "<tr><th>Title</th><th>URL</th><th>Description</th></tr>";

foreach ($searchResults as $result) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($result['title']) . "</td>";
    echo "<td>" . htmlspecialchars($result['url']) . "</td>";
    echo "<td>" . htmlspecialchars($result['description']) . "</td>";
    echo "</tr>";
}
echo "</table>";

?>