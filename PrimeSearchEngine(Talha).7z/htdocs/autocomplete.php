<?php
// autocomplete.php - API endpoint for search suggestions
header('Content-Type: application/json');

// Get the search query
$query = isset($_GET['q']) ? trim($_GET['q']) : '';

if (empty($query)) {
    echo json_encode([]);
    exit;
}

// Include database connection
include 'db_connect.php';

try {
    // Search for matching titles and descriptions in the database
    $stmt = $pdo->prepare("SELECT DISTINCT title FROM websites WHERE title LIKE :query LIMIT 10");
    $stmt->execute(['query' => $query . '%']);
    $results = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Add some popular search suggestions if the query is short
    if (strlen($query) <= 3) {
        $popularSuggestions = [
            'technology',
            'science',
            'news',
            'programming',
            'web development',
            'tutorials',
            'information',
            'education',
            'research',
            'help'
        ];
        
        foreach ($popularSuggestions as $suggestion) {
            if (stripos($suggestion, $query) !== false && !in_array($suggestion, $results)) {
                $results[] = $suggestion;
                if (count($results) >= 8) break;
            }
        }
    }
    
    echo json_encode(array_slice($results, 0, 10));
} catch (PDOException $e) {
    // In case of database error, return empty array
    echo json_encode([]);
}
?>