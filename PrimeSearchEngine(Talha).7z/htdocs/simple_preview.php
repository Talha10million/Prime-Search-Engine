<?php
// Simple preview test - add this to your website
if (isset($_GET['url']) && !empty($_GET['url'])) {
    $url = $_GET['url'];
    // Simple embed for testing
    echo '<!DOCTYPE html>
    <html>
    <head>
        <title>Preview: ' . htmlspecialchars($url) . '</title>
        <style>
            body { margin: 0; padding: 10px; font-family: Arial, sans-serif; background: #333; color: white; }
            .header { background: #ff8c00; padding: 10px; margin: -10px -10px 10px -10px; }
            .close-btn { float: right; cursor: pointer; font-weight: bold; }
        </style>
    </head>
    <body>
        <div class="header">
            <span>Preview: ' . htmlspecialchars($url) . '</span>
            <span class="close-btn" onclick="window.close()">✕</span>
        </div>
        <iframe src="' . htmlspecialchars($url) . '" style="width:100%; height:90%; border:none;"></iframe>
    </body>
    </html>';
} else {
    echo "No URL provided";
}
?>