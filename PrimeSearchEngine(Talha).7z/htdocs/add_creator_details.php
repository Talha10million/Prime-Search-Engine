<?php
// add_creator_details.php - Add detailed creator information to the database

require_once 'db_connect.php';

// Insert your full creator information
$creatorEntries = [
    [
        'url' => 'https://prime-search.com/creator',
        'title' => 'Creator of Prime Search Engine - Developer Profile',
        'description' => 'Meet the developer behind Prime Search Engine - the innovative search platform with holographic effects and advanced features.',
        'content' => 'Prime Search Engine was developed by a passionate web developer focused on creating beautiful and functional search experiences. The platform features holographic cursors, parallax backgrounds, dynamic search results, keyboard navigation, dark/light mode, and many other advanced features. The creator specializes in modern web technologies and UX design to deliver a premium search experience.'
    ],
    [
        'url' => 'https://prime-search.com/about',
        'title' => 'About Prime Search Engine',
        'description' => 'Prime Search Engine - A modern search platform with holographic effects, dark mode, and advanced features.',
        'content' => 'Prime Search Engine is a cutting-edge search platform designed for modern web browsing. Features include holographic cursor effects, parallax backgrounds, keyboard navigation, dark/light mode, search result animations, and more. The engine provides fast and beautiful search results with an engaging user interface.'
    ]
];

$addedCount = 0;

foreach ($creatorEntries as $entry) {
    // Check if similar entry already exists
    $checkSql = "SELECT id FROM websites WHERE title = :title";
    $checkStmt = $pdo->prepare($checkSql);
    $checkStmt->bindValue(':title', $entry['title']);
    $checkStmt->execute();
    
    if ($checkStmt->rowCount() == 0) {
        // Insert new entry
        $insertSql = "INSERT INTO websites (url, title, description, content) VALUES (:url, :title, :description, :content)";
        $insertStmt = $pdo->prepare($insertSql);
        
        $insertStmt->bindValue(':url', $entry['url']);
        $insertStmt->bindValue(':title', $entry['title']);
        $insertStmt->bindValue(':description', $entry['description']);
        $insertStmt->bindValue(':content', substr($entry['content'], 0, 5000));
        
        if ($insertStmt->execute()) {
            $addedCount++;
        }
    }
}

echo "<h2>Creator Information Added</h2>";
echo "<p>Added $addedCount new entries about Prime Search Engine and its creator.</p>";
echo "<p>You can now search for terms like 'Prime creator', 'about Prime', or 'who made Prime' to see this information.</p>";
?>