<?php
// add_creator_info.php - Add creator information to the database

require_once 'db_connect.php';

// Add information about the creator
$creatorInfo = [
    'url' => 'https://your-personal-site.com/about', // placeholder URL
    'title' => 'Creator of Prime Search Engine',
    'description' => 'The innovative developer behind the Prime Search Engine project, featuring advanced visual effects and modern search capabilities.',
    'content' => 'Prime Search Engine was created by a talented developer passionate about creating beautiful, functional web experiences. The project showcases advanced visual effects including holographic cursors, parallax backgrounds, and dynamic search features.'
];

// Check if this entry already exists
$checkSql = "SELECT id FROM websites WHERE title LIKE '%Creator of Prime Search Engine%'";
$checkStmt = $pdo->prepare($checkSql);
$checkStmt->execute();
$exists = $checkStmt->fetch();

if (!$exists) {
    // Insert the creator info
    $sql = "INSERT INTO websites (url, title, description, content) VALUES (:url, :title, :description, :content)";
    $stmt = $pdo->prepare($sql);
    
    $stmt->bindValue(':url', $creatorInfo['url']);
    $stmt->bindValue(':title', $creatorInfo['title']);
    $stmt->bindValue(':description', $creatorInfo['description']);
    $stmt->bindValue(':content', $creatorInfo['content']);
    
    if ($stmt->execute()) {
        echo "Creator information successfully added to the database!";
        echo "<br>Now you can search for 'who created prime' or 'Prime creator' to see this information.";
    } else {
        echo "Error adding creator information.";
    }
} else {
    echo "Creator information already exists in the database.";
}
?>