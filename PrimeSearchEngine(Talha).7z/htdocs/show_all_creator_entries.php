<?php
// show_all_creator_entries.php - Show all entries related to the creator

require_once 'db_connect.php';

// Show ALL entries with any mention of the creator
$searchTerms = ['Muhammad Talha', 'Shadow Emperor', 'Prime creator', 'Prime Search Engine', 'talha10million'];

echo "<h2>All Creator-Related Entries in Database</h2>";

foreach ($searchTerms as $term) {
    echo "<h3>Entries containing '$term':</h3>";
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Title</th><th>URL</th><th>Description</th></tr>";
    
    $sql = "SELECT url, title, description FROM websites WHERE title LIKE :query OR description LIKE :query OR content LIKE :query ORDER BY id DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':query', '%' . $term . '%');
    $stmt->execute();
    
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($results) > 0) {
        foreach ($results as $result) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($result['title']) . "</td>";
            echo "<td>" . htmlspecialchars($result['url']) . "</td>";
            echo "<td>" . htmlspecialchars(substr($result['description'], 0, 100)) . "...</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='3'>No entries found for '$term'</td></tr>";
    }
    echo "</table><br>";
}

// Also show all entries that have 'talha' in any field (your username)
echo "<h3>All entries related to 'talha':</h3>";
echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
echo "<tr><th>Title</th><th>URL</th><th>Description</th></tr>";

$sql = "SELECT url, title, description FROM websites WHERE title LIKE :query OR description LIKE :query OR content LIKE :query ORDER BY id DESC";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':query', '%talha%');
$stmt->execute();

$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($results as $result) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($result['title']) . "</td>";
    echo "<td>" . htmlspecialchars($result['url']) . "</td>";
    echo "<td>" . htmlspecialchars(substr($result['description'], 0, 100)) . "...</td>";
    echo "</tr>";
}
echo "</table>";

?>