<?php
// Redirect to the new index.html page
header("Location: index.html");
exit();
?>